import java.sql.*;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
 
public class Main {
	static Logger logger = Logger.getRootLogger();

	public Main()				//default constructor
	{
		PropertyConfigurator.configure("resources/log4j.properties");	//configure log4j
	}
	static Connection myConn;
	static Statement mystmt;
	 
	public static void main(String[] args) {
		Main mainobj = new Main();
		Signup signupobj = new Signup();
		Login loginobj = new Login();
		System.out.println("----------------------------------------------"); 
		System.out.println("                    Welcome!                  ");
		System.out.println("----------------------------------------------"); 
		try{
			logger.info("Entered into Main Page");
			//myConn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/team2project","root","qwerty12345");
			myConn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/team2project","root","qwerty12345");
			mystmt = myConn.createStatement();
			
		} catch(Exception exc){
			exc.printStackTrace();
		}
		
		System.out.println("1.Signup\n2.Login");
		System.out.println("Enter your choice:");
		Scanner myObj = new Scanner(System.in);
		int choice = myObj.nextInt();
		 
		switch(choice){
			case 1:	signupobj.signuppage();
					break; 	
			
			case 2: loginobj.loginpage();
					break;
			
			default: {	System.out.println("Please enter valid choice.\n");
						mainobj.main(null);
			   		 }
		}
		logger.info("Ended Main Page");
	}
	
		
	
//	private static void view_users_3(){
//		try{  
//			ResultSet myRs = mystmt.executeQuery("select * from users");
//			while(myRs.next()){
//				System.out.println(myRs.getString("user_id")+", "+myRs.getString("password")+", "+myRs.getString("name"));
//			}
//		} catch(Exception exc){
//			exc.printStackTrace();
//		}
//	}

}
