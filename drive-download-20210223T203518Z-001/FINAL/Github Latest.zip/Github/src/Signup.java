import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class Signup {
	
	static Logger logger = Logger.getRootLogger();

	public Signup()		//default constructor
	{
		PropertyConfigurator.configure("resources/log4j.properties");//configure log4j
	}
	static Connection myConn;
	static Statement mystmt;
	
	static String name;
	static int user_id;
	static String email;
	static String password;
	static String e_password;
	static String city;
	static String state;
	static String country;
	
	  
	public void signuppage(){
		Main mainobj = new Main();
			try{ 
				logger.info("Entered Signup Page");
				//myConn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/github_cmpe180b","root","");
				myConn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/team2project","root","qwerty12345");
				myConn.setAutoCommit(false); 
				mystmt = myConn.createStatement();
				
				System.out.println("----------------------SignUp------------------------"); 
				Scanner myObj = new Scanner(System.in);
				//user_id(pk), password, name, email, city, state, country
				
				System.out.println("Enter your name :");
				name = myObj.next();
				
				
				ResultSet user_Id = mystmt.executeQuery("SELECT max(user_id) from user");
				user_Id.next();
				int int_user_Id = ((Number) user_Id.getObject(1)).intValue();
				
				System.out.println("Enter your email Id :");
				email = myObj.next();
				
				System.out.println("Enter your password :"); 
				password = myObj.next();
				
				e_password = "fsfssg";
				
				System.out.println("Enter your city :"); 
				city = myObj.next();
				
				System.out.println("Enter your state :"); 
				state = myObj.next();
				
				System.out.println("Enter your country :"); 
				country = myObj.next();
				
				System.out.println("user name is: "+email+" password is :"+password);
				
				String insertSignup = "INSERT into user(user_id, password, e_password, name, email,city,state,country)"+
				"VALUES(?,?,?,?,?,?,?,?)";
				
				PreparedStatement insertps = myConn.prepareStatement(insertSignup);
				
				insertps.setInt(1,int_user_Id+1);
				insertps.setString(2, password);
				insertps.setString(3, e_password);
				insertps.setString(4, name);
				insertps.setString(5, email);
				insertps.setString(6, city);
				insertps.setString(7, state);
				insertps.setString(8, country);
				insertps.executeUpdate();
				
//				INSERT INTO users (user_id, password, e_password, name, email,city,state,country)
//				VALUES (user_id, password, e_password, name, email,city,state,country);
				
				
				/*String insertSignup ="INSERT into user"
//						+ "VALUES("+user_id+","+password+","+e_password+","+name+","+email+","+city+","+state+","+country+")";
						 VALUES(user_id,password,e_password,name,email,city,state,country)"
				*/ 
				
				//mystmt=myConn.prepareStatement(	INSERT INTO users (user_id, password, e_password, name, email,city,state,country) VALUES(user_id, password, e_password, name, email,city,state,country));
				//int resultset=mystmt.executeUpdate(insertSignup);
				
				myConn.commit();
				mystmt.close();
				myConn.close();
				logger.info("Displayed Signup Menu");
				/*
				 SQL query
				 Add the user in the user table
				 INSERT user VALUES(?,?,?,?,?,?,?,?);
				 If successfull, show msg -> user added successfully
				 
				ResultSet myRs = mystmt.executeQuery("select * from users");
				while(myRs.next()){
					System.out.println(myRs.getSt	ring("user_id")+", "+myRs.getString("password")+", "+myRs.getString("name"));
				}*/
				
				mainobj.main(null);
				
			} catch(Exception exc){
				exc.printStackTrace();
				logger.error("Exception in Signup Page");
			}
		}
}
