import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class Login {
	static Logger logger = Logger.getRootLogger();

	public Login()				//default constructor
	{
		PropertyConfigurator.configure("resources/log4j.properties");	//configure log4j
	}
	
	Home homeobj = new Home();
	static Connection myConn;
	static Statement mystmt;
	static String useremail;
	boolean flag=false;
	  
	public void loginpage(){
			try{ 
				logger.info("Entered into Login Page");
				//myConn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/github_cmpe180b","root","");
				myConn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/team2project","root","qwerty12345");
				mystmt = myConn.createStatement();
				
				Scanner myObj = new Scanner(System.in);
				System.out.println("----------------------Login------------------------"); 
				System.out.println("Enter your email Id :");
				useremail = myObj.next();
				System.out.println("Enter your password :"); 
				String userpass = myObj.next();
				
				ResultSet credCheck = mystmt.executeQuery("SELECT email,password FROM USER");
				while(credCheck.next()) {
				if((useremail.equalsIgnoreCase(credCheck.getString("email")))&&(userpass.equalsIgnoreCase(credCheck.getString("password")))){
						flag=true;
						break;
							}else {
								flag = false;
							}
						}
					
				if(flag==false) {
					System.out.println("Enter valid credentials");
				}else {
					System.out.println("login successful");
					homeobj.homepage();
					logger.info("User Logged in");
				}
				
				
				
				//System.out.println("user name is: "+useremail+" password is :"+userpass);
				
				
				
				
			/*
			 * while (rec.next()) {
			 * 
			 * 
			 * if (useremail == rec.getString("email")) { if (userpass ==
			 * rec.getString("password")) { System.out.println("Logged in!"); } else {
			 * System.out.println("Password did not match username!"); } } else {
			 * System.out.println("Username did not match the database"); }
			 * 
			 * }
			 */
		  
				/*
				 * 
				 Write a query to check if the email and password is correct. 
				 If it is correct-> go ahead
				 else-> ask for mail and password again. (Use goto:)
				 
				 
				 ResultSet myRs = mystmt.executeQuery("select * from users");
				while(myRs.next()){
					System.out.println(myRs.getString("user_id")+", "+myRs.getString("password")+", "+myRs.getString("name"));
				}*/
				
				
				
			} catch(Exception exc){
				exc.printStackTrace();
				logger.error("Exception in Login Page");
			}
		}

}
