
-----------------------------------------------
--SJSU CMPE 138 Spring 2019 Team-2
-----------------------------------------------

DROP TABLE IF EXISTS Followers;
DROP TABLE IF EXISTS project_details;
DROP TABLE IF EXISTS project_files;
DROP TABLE IF EXISTS Makes;
DROP TABLE IF EXISTS commit_details;
DROP TABLE IF EXISTS commits;
DROP TABLE IF EXISTS requests;
DROP TABLE IF EXISTS pullreq_details;
DROP TABLE IF EXISTS pull_requests;
DROP TABLE IF EXISTS branches;
DROP TABLE IF EXISTS respository;
DROP TABLE IF EXISTS user;