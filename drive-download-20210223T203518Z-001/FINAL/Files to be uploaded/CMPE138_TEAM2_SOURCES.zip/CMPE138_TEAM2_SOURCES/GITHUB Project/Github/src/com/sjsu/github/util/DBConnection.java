//SJSU CMPE 138 Spring 2019 Team-2
package com.sjsu.github.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import oracle.jdbc.pool.OracleDataSource;

public class DBConnection {

	private static String url = "jdbc:mysql://127.0.0.1:3306/team2project";    
    private static String driverName = "com.mysql.cj.jdbc.Driver";   
    private static String username = "root";   
    private static String password = "qwerty12345";
    private static Connection myConn;

    public static Connection getConnection() {
        try {
            Class.forName(driverName);
            try {
            	myConn = DriverManager.getConnection(url, username, password);
            } catch (SQLException ex) {
                System.out.println("Failed to create the database connection."); 
            }
        } catch (ClassNotFoundException ex) {
            System.out.println("Driver not found."); 
        }
        return myConn;
    }

}
